# Web3 Namecard

## Dev

```bash
npm i
npm run dev
```
