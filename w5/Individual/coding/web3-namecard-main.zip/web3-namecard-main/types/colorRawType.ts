export type colorRawType = {
  _rgb: [number, number, number]
}