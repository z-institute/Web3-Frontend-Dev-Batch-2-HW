export type ensDataType = {
  ensName?: string,
  avatarUrl?: string,
  twitter?: string,
  github?: string,
  websiteUrl?: string
  email?: string,
  ethAddress?: string,
}